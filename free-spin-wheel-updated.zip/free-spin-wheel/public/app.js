const wheel = document.getElementById("wheel");
const spinBtn = document.getElementById("spinBtn");
const statusEl = document.getElementById("status");
const resultEl = document.getElementById("result");
const resultTitle = document.getElementById("resultTitle");
const resultIcon = document.getElementById("resultIcon");
const claimWrap = document.getElementById("claimWrap");
const claimCode = document.getElementById("claimCode");
const oddsTable = document.getElementById("oddsTable");

const token = new URLSearchParams(location.search).get("t");
let odds = [];
let rotation = 0;

function formatPercent(n) {
  if (n < 0.1) return n.toFixed(2) + "%";
  if (n < 1) return n.toFixed(1) + "%";
  return n.toFixed(n % 1 === 0 ? 0 : 1) + "%";
}

async function init() {
  const r = await fetch("/api/odds");
  const data = await r.json();
  odds = data.prizes;
  renderWheelLabels();
  oddsTable.innerHTML = `<table>${odds.map(p => `<tr><td>${escapeHtml(p.shortLabel)}</td><td>${formatPercent(p.percent)}</td></tr>`).join("")}</table>`;

  if (!token) {
    spinBtn.disabled = true;
    statusEl.textContent = "Open your personal spin link to play.";
  }
}

function renderWheelLabels() {
  document.querySelectorAll(".wheel-label").forEach(x => x.remove());
  // Equal visual sectors for readability. Exact selection odds are disclosed below.
  const sectorSize = 360 / odds.length;
  odds.forEach((p, i) => {
    const label = document.createElement("div");
    label.className = "wheel-label";
    const angle = i * sectorSize + sectorSize / 2;
    label.style.transform = `rotate(${angle}deg) translate(22%, -50%)`;
    label.innerHTML = `<span style="display:inline-block;transform:rotate(90deg)">${escapeHtml(p.shortLabel)}</span>`;
    wheel.appendChild(label);
  });
}

spinBtn.addEventListener("click", async () => {
  if (!token) return;
  spinBtn.disabled = true;
  resultEl.classList.add("hidden");
  statusEl.textContent = "Checking your spin…";

  try {
    const response = await fetch("/api/spin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Spin failed");

    const index = Math.max(0, odds.findIndex(p => p.id === data.prizeId));
    const sectorSize = 360 / odds.length;
    const sectorCenter = index * sectorSize + sectorSize / 2;
    const targetAtPointer = 360 - sectorCenter;
    const currentNormalized = ((rotation % 360) + 360) % 360;
    const delta = ((targetAtPointer - currentNormalized + 360) % 360) + 360 * 6;
    rotation += delta;

    statusEl.textContent = data.alreadySpun ? "Showing your saved result…" : "Spinning…";
    wheel.style.transform = `rotate(${rotation}deg)`;

    setTimeout(() => showResult(data), 5250);
  } catch (err) {
    statusEl.textContent = err.message;
    spinBtn.disabled = false;
  }
});

function showResult(data) {
  statusEl.textContent = data.alreadySpun ? "You already used your free spin. This is your saved result." : "Spin complete.";
  resultEl.classList.remove("hidden");
  resultTitle.textContent = data.prizeLabel;
  resultIcon.textContent = data.amount > 0 ? "🎉" : "🍀";
  if (data.claimCode) {
    claimCode.textContent = data.claimCode;
    claimWrap.classList.remove("hidden");
  } else {
    claimWrap.classList.add("hidden");
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[ch]));
}

init().catch(() => {
  statusEl.textContent = "Could not load the game.";
  spinBtn.disabled = true;
});
